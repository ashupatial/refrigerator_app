﻿

using System;
using System.Collections.Generic;

namespace RefrigeratorApp
{
    class Product
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public DateTime ExpirationDate { get; set; }
    }

    class Refrigerator
    {
        private List<Product> products = new List<Product>();

        public void InsertProduct(string name, double quantity, DateTime expirationDate)
        {
            products.Add(new Product { Name = name, Quantity = quantity, ExpirationDate = expirationDate });
            Console.WriteLine($"Product '{name}' inserted into the refrigerator.");
        }

        public void ConsumeProduct(string name, double consumedQuantity)
        {
            Product product = products.Find(p => p.Name == name);
            if (product != null)
            {
                if (consumedQuantity <= product.Quantity)
                {
                    product.Quantity -= consumedQuantity;
                    Console.WriteLine($"Consumed {consumedQuantity} from product '{name}'.");
                }
                else
                {
                    Console.WriteLine($"Not enough quantity of product '{name}' in the refrigerator.");
                }
            }
            else
            {
                Console.WriteLine($"Product '{name}' not found in the refrigerator.");
            }
        }

        public void ShowCurrentStatus()
        {
            Console.WriteLine("Current status of the refrigerator:");
            foreach (Product product in products)
            {
                Console.WriteLine($"Product: {product.Name}, Quantity: {product.Quantity}, Expiration Date: {product.ExpirationDate}");
            }
        }

        public void CheckExpiry()
        {
            DateTime currentDate = DateTime.Now;
            foreach (Product product in products)
            {
                if (currentDate >= product.ExpirationDate)
                {
                    Console.WriteLine($"Product '{product.Name}' has expired. Removing from stock.");
                    products.Remove(product);
                    break; // Removing only one expired item per check
                }
                else if (product.ExpirationDate.Subtract(currentDate).TotalDays <= 3)
                {
                    Console.WriteLine($"Product '{product.Name}' is about to expire. Please use it soon.");
                }
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Refrigerator refrigerator = new Refrigerator();

            while (true)
            {
                Console.WriteLine("Select an option:");
                Console.WriteLine("1. Insert Product");
                Console.WriteLine("2. Consume Product");
                Console.WriteLine("3. Show Current Status");
                Console.WriteLine("4. Check Expiry");
                Console.WriteLine("5. Exit");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.Write("Enter product name: ");
                        string productName = Console.ReadLine();
                        Console.Write("Enter quantity: ");
                        double quantity = double.Parse(Console.ReadLine());
                        Console.Write("Enter expiration date (yyyy-mm-dd): ");
                        DateTime expirationDate = DateTime.Parse(Console.ReadLine());
                        refrigerator.InsertProduct(productName, quantity, expirationDate);
                        break;

                    case 2:
                        Console.Write("Enter product name: ");
                        string productToConsume = Console.ReadLine();
                        Console.Write("Enter consumed quantity: ");
                        double consumedQuantity = double.Parse(Console.ReadLine());
                        refrigerator.ConsumeProduct(productToConsume, consumedQuantity);
                        break;

                    case 3:
                        refrigerator.ShowCurrentStatus();
                        break;

                    case 4:
                        refrigerator.CheckExpiry();
                        break;

                    case 5:
                        return;

                    default:
                        Console.WriteLine("Invalid choice. Please select a valid option.");
                        break;
                }
            }
        }
    }
}